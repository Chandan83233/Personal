﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Exceptions;
using CMS.Entities;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace CMS.DataAccessLayer
{
    public class CustomerDAL
    {
        private static List<Customer> customerList = new List<Customer>();

        //Add a new Customer
        public static bool AddCusotmerDAL(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
                customerList.Add(newCustomer);
                customerAdded = true;
            }
            catch(CustomerException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return customerAdded;
        }

        //Customer Summary
        public static List<Customer> ListAllCustomersDAL()
        {
            return customerList;
        }

        //Search Customer by ID
        public static Customer SearchCustomerByIdDAL(int searchID)
        {
            Customer searchedCustomer = null;
            try
            {
                searchedCustomer = customerList.Find(customer=>customer.CustomerID==searchID);
            }
            catch(CustomerException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return searchedCustomer;
        }

        //Search Customer by Name
        public static List<Customer> SearchCustomerByNameDAL(string searchName)
        {
            List<Customer> searchedCustomers = new List<Customer>();

            try
            {
                for (int i = 0; i < customerList.Count; i++)
                {
                    if(customerList[i].CustomerName == searchName)
                    {
                        searchedCustomers.Add(customerList[i]);
                    }
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return searchedCustomers;
        }

        //Modify Customer 

        public static bool ModifyCustomerDAL(Customer modifiedCustomer)
        {
            bool customerModified = false;

            try
            {
                for (int i = 0; i < customerList.Count; i++)
                {
                    if(customerList[i].CustomerID==modifiedCustomer.CustomerID)
                    {
                        customerList[i].CustomerName = modifiedCustomer.CustomerName;
                        customerList[i].Age = modifiedCustomer.Age;
                        customerList[i].City = modifiedCustomer.City;
                        customerList[i].Phone = modifiedCustomer.Phone;
                        customerList[i].Pincode = modifiedCustomer.Pincode;
                        customerModified = true;
                    }
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return customerModified;
        }

        //Remove Customer

        public static bool RemoveCustomerDAL(int deleteID)
        {
            bool customerDeleted = false;

            try
            {
                Customer deletedCustomer = customerList.Find(customer=>customer.CustomerID==deleteID);
                
                if(deletedCustomer != null)
                {
                    customerList.Remove(deletedCustomer);
                    customerDeleted = true;
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return customerDeleted;
        }

        //Serialize Customer Data into SerializedCustomerList.txt

        public static bool SerializeCustomerDAL()
        {
            bool customersSerialized = false;

            try
            {
                FileStream fs = new FileStream("SerializedCustomerList.txt",FileMode.Create,FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();

                bin.Serialize(fs, customerList);
                customersSerialized = true;
                fs.Close();
            }
            catch(CustomerException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return customersSerialized;
        }

        //Deserialize Customer Data fromSerializedCustomerList.txt

        public static List<Customer> DeserializeCustomerDAL()
        {
            List<Customer> deserializedCustList = new List<Customer>();

            try
            {
                FileStream fs = new FileStream("SerializedCustomerList.txt", FileMode.Open,FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();

                deserializedCustList = bin.Deserialize(fs) as List<Customer>;
                fs.Close();
            }
            catch(CustomerException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return deserializedCustList;
        }

    }
}
