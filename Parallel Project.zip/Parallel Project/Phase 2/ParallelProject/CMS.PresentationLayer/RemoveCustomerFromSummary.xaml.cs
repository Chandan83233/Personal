﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for RemoveCustomerFromSummary.xaml
    /// </summary>
    public partial class RemoveCustomerFromSummary : Window
    {
        
        public RemoveCustomerFromSummary()
        {
            InitializeComponent();
            List<Customer> customerList = CustomerBLL.ListAllCustomersBLL();
            dgCustomers.ItemsSource = customerList;
        }

        //private void DgCustomers_CurrentCellChanged(object sender, EventArgs e)
        //{
        //    MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Do you want to remove this Customer?", "Delete Confirmation", System.Windows.MessageBoxButton.YesNo);

        //    if (messageBoxResult == MessageBoxResult.Yes)
        //    {
        //        Customer row = (Customer)dgCustomers.SelectedItem;

        //        int deleteCustomerID = row.CustomerID;

        //        bool customerDeleted = CustomerBLL.RemoveCustomerBLL(deleteCustomerID);

        //        if (customerDeleted)
        //        {
        //            MessageBox.Show("Customer Removed");
        //            dgCustomers.ItemsSource = CustomerBLL.ListAllCustomersBLL();
        //        }
                    
                    
        //        else
        //            MessageBox.Show("Customer could not be Removed");
        //    }
        //}

        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Do you want to remove this Customer?", "Delete Confirmation", System.Windows.MessageBoxButton.YesNo);

            if (messageBoxResult == MessageBoxResult.Yes)
            {
                Customer row = (Customer)dgCustomers.SelectedItem;

                int deleteCustomerID = row.CustomerID;

                bool customerDeleted = CustomerBLL.RemoveCustomerBLL(deleteCustomerID);

                if (customerDeleted)
                {
                    MessageBox.Show("Customer Removed");
                    dgCustomers.ItemsSource = CustomerBLL.ListAllCustomersBLL();
                }


                else
                    MessageBox.Show("Customer could not be Removed");
            }
        }
    }
}
