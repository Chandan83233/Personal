﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for RemoveCustomerMenu.xaml
    /// </summary>
    public partial class RemoveCustomerMenu : Window
    {
        public RemoveCustomerMenu()
        {
            InitializeComponent();
        }

        private void DisableAllButtons()
        {
            btnRemoveByID.IsEnabled = false;
            btnRemoveByName.IsEnabled = false;
            btnRemoveMenu.IsEnabled = false;

            btnExit.IsEnabled = false;
        }

        public void EnableAllButtons()
        {
            btnRemoveByID.IsEnabled = true;
            btnRemoveByName.IsEnabled = true;
            btnRemoveMenu.IsEnabled = true;

            btnExit.IsEnabled = true;
        }

        private void BtnRemoveByID_Click(object sender, RoutedEventArgs e)
        {
            RemoveCustomerByID win1 = new RemoveCustomerByID();
            win1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win1.Show();
            DisableAllButtons();
        }

        private void BtnRemoveByName_Click(object sender, RoutedEventArgs e)
        {
            RemoveCustomerByName win2 = new RemoveCustomerByName();
            win2.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win2.Show();
            DisableAllButtons();
        }

        private void BtnRemoveMenu_Click(object sender, RoutedEventArgs e)
        {
            RemoveCustomerFromSummary win3 = new RemoveCustomerFromSummary();
            win3.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win3.Show();
            DisableAllButtons();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_MouseEnter(object sender, MouseEventArgs e)
        {
            EnableAllButtons();
        }

    }
}
