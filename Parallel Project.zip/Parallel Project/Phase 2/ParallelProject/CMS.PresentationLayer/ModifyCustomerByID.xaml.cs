﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ModifyCustomerByID.xaml
    /// </summary>
    public partial class ModifyCustomerByID : Window
    {
        public ModifyCustomerByID()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchCustomerID;

                searchCustomerID = Convert.ToInt32(txtID.Text);
                Customer searchCustomer = CustomerBLL.SearchCustomerByIdBLL(searchCustomerID);
                if (searchCustomer != null)
                {
                    txtName.Text = searchCustomer.CustomerName;
                    txtCity.Text = searchCustomer.City;
                    txtAge.Text = searchCustomer.Age.ToString();
                    txtPhone.Text = searchCustomer.Phone.ToString();
                    txtPincode.Text = searchCustomer.Pincode.ToString();
                }
                else
                {
                    MessageBox.Show("No Customer Details Available");
                }

            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try { 

                int updateCustomerID = Convert.ToInt32(txtID.Text);

                Customer updatedCustomer = CustomerBLL.SearchCustomerByIdBLL(updateCustomerID);

                if (updatedCustomer != null && txtName.Text != "" && txtCity.Text != "" && txtAge.Text != "" && txtPhone.Text != "" && txtPincode.Text != "")
                {
                    updatedCustomer.CustomerName = txtName.Text;
                    updatedCustomer.City = txtCity.Text;
                    string age = "0" + txtAge.Text;
                    updatedCustomer.Age = Convert.ToInt32(txtAge.Text);
                    string phn = "0" + txtPhone.Text;
                    updatedCustomer.Phone = Convert.ToInt64(txtPhone.Text);
                    string pin = "0" + txtPincode.Text;
                    updatedCustomer.Pincode = Convert.ToInt32(txtPincode.Text);

                    bool customerUpdated = CustomerBLL.ModifyCustomerBLL(updatedCustomer);

                    if (customerUpdated)
                        MessageBox.Show("Customer Modified");
                    else
                        MessageBox.Show("Customer could not be Modified");
                }
                else
                {
                    MessageBox.Show("No Customer Details Available");
                }

            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
