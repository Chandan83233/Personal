﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace CMS.DataAccessLayer
{
    class CustomerConfiguration
    {
        private static string providerName;

        public static string ProviderName
        {
            get { return CustomerConfiguration.providerName; }
            set { CustomerConfiguration.providerName = value; }
        }

        private static string connectionString;

        public static string ConnectionString
        {
            get { return CustomerConfiguration.connectionString; }
            set { CustomerConfiguration.connectionString = value; }
        }

        static CustomerConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["customerConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["customerConnection"].ConnectionString;

        }
    }
}
