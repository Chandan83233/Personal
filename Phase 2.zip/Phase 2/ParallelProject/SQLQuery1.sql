USE Training_13Aug19_Pune
GO

CREATE TABLE [Aritra_46003367].[Customer]
(
CustomerID INT PRIMARY KEY IDENTITY(1,1),
CustomerName VARCHAR(50) NOT NULL,
City VARCHAR(30) NOT NULL,
Age INT NOT NULL,
Phone BIGINT NOT NULL,
Pincode INT NOT NULL
);

CREATE PROCEDURE [Aritra_46003367].[InsertCustomer]
@CustomerName VARCHAR(50),
@City VARCHAR(30),
@Age INT,
@Phone BIGINT,
@Pincode INT
AS
BEGIN
	INSERT INTO [Aritra_46003367].[Customer] VALUES (@CustomerName,@City,@Age,@Phone,@Pincode)
END

exec Aritra_46003367.InsertCustomer @CustomerName='Aritra',@City='Kharagpur',@Age=24,@Phone=9641462407,@Pincode=721301;

CREATE PROCEDURE [Aritra_46003367].[SelectAllCustomers]
AS
BEGIN
	SELECT * FROM [Aritra_46003367].[Customer]
END

CREATE PROCEDURE [Aritra_46003367].[SelectCustomer]
@CustomerID INT
AS
BEGIN
	SELECT * FROM [Aritra_46003367].[Customer] WHERE CustomerID=@CustomerID
END

CREATE PROCEDURE [Aritra_46003367].[UpdateCustomer]
@CustomerID INT,
@CustomerName VARCHAR(50),
@City VARCHAR(30),
@Age INT,
@Phone BIGINT,
@Pincode INT
AS
BEGIN
	UPDATE [Aritra_46003367].[Customer] SET CustomerName=@CustomerName, City=@City, Age=@Age, Phone=@Phone, Pincode=@Pincode WHERE CustomerID=@CustomerID
END

CREATE PROCEDURE [Aritra_46003367].[DeleteCustomer]
@CustomerID INT
AS
BEGIN
	DELETE FROM [Aritra_46003367].[Customer] WHERE CustomerID=@CustomerID
END

CREATE PROCEDURE [Aritra_46003367].[SelectByNameCustomer]
@CustomerName VARCHAR(50)
AS
BEGIN
	SELECT * FROM [Aritra_46003367].[Customer] WHERE CustomerName Like ('%'+@CustomerName+'%') AND @CustomerName <> ''
END

CREATE PROCEDURE [Aritra_46003367].[ReturnCustomerID]
AS
BEGIN
	SELECT IDENT_CURRENT('[Aritra_46003367].[Customer]')+1
END
