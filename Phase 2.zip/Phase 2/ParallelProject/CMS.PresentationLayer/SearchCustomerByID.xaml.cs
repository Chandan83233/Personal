﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for SearchCustomerByID.xaml
    /// </summary>
    public partial class SearchCustomerByID : Window
    {
        public SearchCustomerByID()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchCustomerID;

                if (string.IsNullOrEmpty(txtID.Text))
                {
                    MessageBox.Show("Customer ID cannot be null or empty");
                    txtID.Text = "";
                    txtName.Text = "";
                    txtCity.Text = "";
                    txtAge.Text = "";
                    txtPhone.Text = "";
                    txtPincode.Text = "";
                }
                else{
                    searchCustomerID = Convert.ToInt32(txtID.Text);
                    Customer searchCustomer = CustomerBLL.SearchCustomerByIdBLL(searchCustomerID);
                    if (searchCustomer != null)
                    {
                        txtName.Text = searchCustomer.CustomerName;
                        txtCity.Text = searchCustomer.City;
                        txtAge.Text = searchCustomer.Age.ToString();
                        txtPhone.Text = searchCustomer.Phone.ToString();
                        txtPincode.Text = searchCustomer.Pincode.ToString();

                    }
                    else
                    {
                        MessageBox.Show("No Customer details available");
                        txtID.Text = "";
                        txtName.Text = "";
                        txtCity.Text = "";
                        txtAge.Text = "";
                        txtPhone.Text = "";
                        txtPincode.Text = "";
                    }
                }
                

            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            SearchCustomerMenu.searchMenuWin1.EnableAllButtons();
        }
    }
}
