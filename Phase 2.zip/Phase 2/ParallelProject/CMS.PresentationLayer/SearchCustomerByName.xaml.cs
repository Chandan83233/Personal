﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for SearchCustomerByName.xaml
    /// </summary>
    public partial class SearchCustomerByName : Window
    {
        public SearchCustomerByName()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string searchCustomerName = txtName.Text;

                List<Customer> searchCustomers = CustomerBLL.SearchCustomerByNameBLL(searchCustomerName);

                if (searchCustomers != null)
                {
                    dgCustomers.HeadersVisibility = DataGridHeadersVisibility.All;
                    dgCustomers.ItemsSource = searchCustomers;

                }
                else
                {
                    dgCustomers.HeadersVisibility = DataGridHeadersVisibility.None;
                    dgCustomers.ItemsSource = searchCustomers;
                    MessageBox.Show("No Customer details available");
                }


            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            SearchCustomerMenu.searchMenuWin1.EnableAllButtons();
        }
    }
}
