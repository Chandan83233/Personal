﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for RemoveCustomerByName.xaml
    /// </summary>
    public partial class RemoveCustomerByName : Window
    {

         
        public RemoveCustomerByName()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string searchCustomerName = txtName.Text;

                List<Customer> searchCustomers = CustomerBLL.SearchCustomerByNameBLL(searchCustomerName);

                if (searchCustomers != null)
                {
                    lblSelect.Visibility = Visibility.Visible;
                    dgCustomers.HeadersVisibility = DataGridHeadersVisibility.All;
                    dgCustomers.ItemsSource = searchCustomers;
                }
                else
                {
                    
                    MessageBox.Show("No Customer details available");
                    dgCustomers.HeadersVisibility = DataGridHeadersVisibility.None;
                    dgCustomers.ItemsSource = searchCustomers;
                }


            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            Customer row = (Customer)dgCustomers.SelectedItem;

            if (row != null)
            {

                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Do you want to remove this Customer?", "Delete Confirmation", System.Windows.MessageBoxButton.YesNo);

                if (messageBoxResult == MessageBoxResult.Yes)
                {
                
                    int deleteCustomerID = row.CustomerID;

                    bool customerDeleted = CustomerBLL.RemoveCustomerBLL(deleteCustomerID);

                    if (customerDeleted)
                    {
                        MessageBox.Show("Customer removed");

                        string searchCustomerName = txtName.Text;
                        List<Customer> customerList = CustomerBLL.SearchCustomerByNameBLL(searchCustomerName);

                        if (customerList.Count == 0)
                        {
                            lblSelect.Visibility = Visibility.Hidden;
                            dgCustomers.HeadersVisibility = DataGridHeadersVisibility.None;
                            
                        }
                        
                        dgCustomers.ItemsSource = customerList;

                    }

                    else
                        MessageBox.Show("Customer could not be removed");
                }                  
            }
            else
            {
                MessageBox.Show("No Customer selected");
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            RemoveCustomerMenu.removeMenuWin1.EnableAllButtons();
        }
    }
}
