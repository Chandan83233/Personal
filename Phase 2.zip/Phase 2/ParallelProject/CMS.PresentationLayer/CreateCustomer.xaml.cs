﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for CreateCustomer.xaml
    /// </summary>
    public partial class CreateCustomer : Window
    {
        public CreateCustomer()
        {
            InitializeComponent();
            txtID.Text = CustomerBLL.ReturnCustomerIdBLL().ToString() + " (Auto-generated)";
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Customer newCustomer = new Customer();
                //newCustomer.CustomerID = Convert.ToInt32(txtID.Text);
                newCustomer.CustomerName = txtName.Text;

                newCustomer.City = txtCity.Text;

                string age = "0"+ txtAge.Text;
                newCustomer.Age = Convert.ToInt32(age);

                string phn = "0" + txtPhone.Text;
                newCustomer.Phone = Convert.ToInt64(phn);

                string pin = "0" + txtPincode.Text;
                newCustomer.Pincode = Convert.ToInt32(pin);

                bool customerAdded = CustomerBLL.AddCustomerBLL(newCustomer);

                if (customerAdded)
                {
                    MessageBox.Show("Customer created");
                    txtID.Text = "";
                    txtName.Text = "";
                    txtCity.Text = "";
                    txtAge.Text = "";
                    txtPhone.Text = "";
                    txtPincode.Text = "";
                }
                    
                else
                    MessageBox.Show("Customer could not be created");
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            CMSMainMenu.mainWin1.EnableAllButtons();
        }
    }
}
