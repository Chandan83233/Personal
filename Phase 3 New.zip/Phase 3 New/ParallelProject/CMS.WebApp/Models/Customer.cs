namespace CMS.WebApp.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Aritra_46003367.Customer")]
    public partial class Customer
    {
        [Display(Name = "Customer ID")]
        public int CustomerID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage ="Customer Name is required!")]
        [StringLength(50)]
        public string CustomerName { get; set; }

        [Required(ErrorMessage = "City is required!")]
        [StringLength(30)]
        public string City { get; set; }

        [Required(ErrorMessage = "Age is required!")] 
        [Range(0,100,ErrorMessage ="Age must be between 0 and 100!")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Phone Number is required!")]
        public long Phone { get; set; }

        [Required(ErrorMessage = "Pincode is required!")]
        public int Pincode { get; set; }
    }
}
