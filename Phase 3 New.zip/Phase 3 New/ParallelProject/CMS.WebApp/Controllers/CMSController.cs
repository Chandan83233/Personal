﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CMS.WebApp.Models;

namespace CMS.WebApp.Controllers
{
    public class CMSController : Controller
    {
        CMSEntities db = new CMSEntities();
        // GET: CMS
        public ActionResult CustomerSummary()
        {
            var customerList = db.Customers;
            return View(customerList.ToList());
        }

        public ActionResult MainMenu()
        {
            return View();
        }

        public ActionResult SearchMenu()
        {
            return View();
        }

        public ActionResult SearchByID()
        {
            return View();
        }

        [HttpGet]
        public void addToCart(string item, int quantity)
        {
            return "Your cart now contains: " + quantity + " " + item;
            // You may do something else
        }

        public ActionResult SearchByName()
        {
            return View();
        }

        public ActionResult ModifyMenu()
        {
            return View();
        }

        public ActionResult ModifyByID()
        {
            return View();
        }

        public ActionResult ModifyByName()
        {
            return View();
        }

        public ActionResult ModifyFromSummary()
        {
            var customerList = db.Customers;
            return View(customerList.ToList());
        }

        public ActionResult RemoveMenu()
        {
            return View();
        }


        public ActionResult RemoveByID()
        {
            return View();
        }

        public ActionResult RemoveByName()
        {
            return View();
        }

        public ActionResult RemoveFromSummary()
        {
            var customerList = db.Customers;
            return View(customerList.ToList());
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                HttpNotFound();
            }

            return View(customer);
        }

        //GET: /Employee/Create
        public ActionResult Create()
        {
            return View();
        }

        //POST: /Employee/Create
        [HttpPost]
        public ActionResult Create([Bind(Include = "CustomerID,CustomerName,City,Age,Phone,Pincode")]Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Customers.Add(customer);
                db.SaveChanges();

                return RedirectToAction("MainMenu");
            }

            return View(customer);
        }

        //GET: /Employee/Edit
        public ActionResult Modify(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Customer employee = db.Customers.Find(id);

            if (employee == null)
            {
                HttpNotFound();
            }

            return View(employee);
        }

        //POST: /Employee/Edit
        [HttpPost]
        public ActionResult Modify([Bind(Include = "CustomerID,CustomerName,City,Age,Phone,Pincode")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(customer).State = EntityState.Modified;
                db.SaveChanges();

                return RedirectToAction("ModifyFromSummary");
            }

            return View(customer);
        }

        //GET: /Employee/Delete
        public ActionResult Remove(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Customer employee = db.Customers.Find(id);

            if (employee == null)
            {
                HttpNotFound();
            }

            return View(employee);
        }

        //POST: /Employee/Delete
        [HttpPost, ActionName("Remove")]
        public ActionResult RemoveConfirmed(int id)
        {
            Customer employee = db.Customers.Find(id);

            db.Customers.Remove(employee);
            db.SaveChanges();

            return RedirectToAction("RemoveFromSummary");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }

            base.Dispose(disposing);
        }
    }
}