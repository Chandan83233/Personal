﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;

namespace EmployeeTableStorage_OnAzure
{
    class Program
    {
        public static CloudStorageAccount storageAccount = null;
        public static CloudTableClient tableClient = null;
        public static CloudTable table = null;

        static void Main(string[] args)
        {
            try
            {
                CreateTableStorage();

                int choice;
                do
                {
                    Console.WriteLine("\n---------------------------------Employee Menu----------------------------------");

                    Console.WriteLine("1. Add a new Employee");
                    Console.WriteLine("2. Retrieve Employee details");
                    Console.WriteLine("3. Delete Employee details by RowKey");
                    Console.WriteLine("4. Exit");

                    Console.WriteLine("\n--------------------------------------------------------------------------------");

                    Console.WriteLine("\nEnter your choice: ");
                    choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            AddEmployee();
                            break;
                        case 2:
                            RetriveAllEmployees();
                            break;
                        case 3:
                            DeleteEmployee();
                            break;
                        case 4:
                            DeleteTableStorage();
                            Console.WriteLine("\nPress any key to exit:");
                            Console.ReadKey();
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("\nInvalid Choice!");
                            break;
                    }

                } while (choice != 4);
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method to create Employee table on Azure table Storage
        private static void CreateTableStorage()
        {
            storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));
            tableClient = storageAccount.CreateCloudTableClient();
            table = tableClient.GetTableReference("Employees");
            table.CreateIfNotExists();

            Console.WriteLine("Table Employees Created!");
        }

        //Method to add a new Employee to Employee table on Azure table Storage
        private static void AddEmployee()
        {


            try
            {
                Employee newEmp = new Employee();

                Console.WriteLine("\nEnter Employee ID: ");
                newEmp.RowKey = Console.ReadLine();
                Console.WriteLine("\nEnter Employee Name: ");
                newEmp.Name = Console.ReadLine();
                Console.WriteLine("\nEnter Age: ");
                newEmp.Age = int.Parse(Console.ReadLine());
                Console.WriteLine("\nEnter Department: ");
                newEmp.PartitionKey = Console.ReadLine();


                TableOperation tableOperation = TableOperation.Insert(newEmp);
                table.Execute(tableOperation);
                Console.WriteLine("\nEmployee Added!");
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method to retrieve all Employees from Employee table on Azure table Storage
        private static void RetriveAllEmployees()
        {

            List<Employee> empList = new List<Employee>();
            TableQuery<Employee> query = new TableQuery<Employee>();
            foreach (Employee entity in table.ExecuteQuery(query))
            {

                Employee emp = new Employee(entity.PartitionKey, entity.RowKey);

                emp.Name = entity.Name;
                emp.Age = entity.Age;
                emp.PartitionKey = entity.PartitionKey;
                emp.RowKey = entity.RowKey;

                empList.Add(emp);
            }

            if(empList.Count>0)
            {
                Console.WriteLine("\nList of Employees: ");
                foreach (Employee e in empList)
                {
                    Console.WriteLine($"\n\tEmployee-ID: {e.RowKey}\n\tName: {e.Name}\n\tAge: {e.Age}\n\tDepartment-Name: {e.PartitionKey}");
                    //e.ToString();
                }
            }
            else
            {
                Console.WriteLine("\nNo Employee details available!");
            }
           
        }

        //Method to delete an Employee from Employee table on Azure table Storage
        private static void DeleteEmployee()
        {
            Console.WriteLine("\nEnter the Department of the Employee to be deleted: ");
            string dept = Console.ReadLine();
            Console.WriteLine("\nEnter the Employee ID to be deleted: ");
            string id = Console.ReadLine();

            TableOperation tableOperation = TableOperation.Retrieve<Employee>(dept, id);

            
            TableResult tableResult = table.Execute(tableOperation);

            if (tableResult.Result != null)
            {
                Employee emp = tableResult.Result as Employee;
                TableOperation deleteOperation = TableOperation.Delete(emp);
                table.Execute(deleteOperation);
                Console.WriteLine("\nEmployee Deleted Successfully!");
            }
        }

        //Method to delete Employee table from Azure table Storage
        private static void DeleteTableStorage()
        {
            table.DeleteIfExists();
            Console.WriteLine("\nTable Employees Deleted!");
        }

    }
}
