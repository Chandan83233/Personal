﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage.Table;

namespace EmployeeTableStorage_OnAzure
{
    class Employee: TableEntity
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public Employee()
        {

        }

        public Employee(string partitionKey, string rowKey)
        {
            this.PartitionKey = partitionKey;
            this.RowKey = rowKey;
        }

    }
}
